MSRVTT-QA

The dataset is based on MSR-VTT (http://ms-multimedia-challenge.com/2016/dataset), please put the corresponding videos under the directory 'video'.

Data split(video_id):
Train: video0 : video6512 (6513)
Val: video6513 : video7009 (497)
Test: video7010 : video9999 (2990) 